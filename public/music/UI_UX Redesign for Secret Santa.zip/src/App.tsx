import { useState } from "react";
import { Navigation } from "./components/Navigation";
import { Footer } from "./components/Footer";
import { SnowfallEffect } from "./components/SnowfallEffect";
import { Hero } from "./components/Hero";
import { SecretSantaForm } from "./components/SecretSantaForm";
import { HowItWorksA } from "./components/HowItWorksA";
import { FAQ } from "./components/FAQ";
import { PrivacyPolicy } from "./components/PrivacyPolicy";
import { SuccessModal } from "./components/SuccessModal";
import { BackToTopOrnament } from "./components/BackToTopOrnament";
import { MusicPlayer } from "./components/MusicPlayer";

type Page = 'home' | 'tool' | 'how-it-works' | 'faq' | 'privacy';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  const handleNavigate = (page: string) => {
    setCurrentPage(page as Page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleGetStarted = () => {
    setCurrentPage('tool');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleFormSuccess = () => {
    setShowSuccessModal(true);
  };

  const handleCloseSuccess = () => {
    setShowSuccessModal(false);
    setCurrentPage('home');
  };

  const handleCreateAnother = () => {
    setShowSuccessModal(false);
    setCurrentPage('tool');
  };

  return (
    <div className="min-h-screen bg-[#F9F6F0] relative">
      <SnowfallEffect />
      
      <div className="relative z-10">
        <Navigation currentPage={currentPage} onNavigate={handleNavigate} />
        
        <main>
          {currentPage === 'home' && <Hero onGetStarted={handleGetStarted} />}
          {currentPage === 'tool' && <SecretSantaForm onSuccess={handleFormSuccess} />}
          {currentPage === 'how-it-works' && <HowItWorksA />}
          {currentPage === 'faq' && <FAQ />}
          {currentPage === 'privacy' && <PrivacyPolicy />}
        </main>
        
        <Footer />
      </div>

      <BackToTopOrnament />
      <MusicPlayer />

      {showSuccessModal && (
        <SuccessModal 
          onClose={handleCloseSuccess}
          onCreateAnother={handleCreateAnother}
        />
      )}
    </div>
  );
}